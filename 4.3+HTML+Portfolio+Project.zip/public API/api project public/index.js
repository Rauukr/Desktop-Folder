import express from "express";
import axios from "axios";

const app = express();
const port = 3000; // Change the port number as needed

// Add your API routes and middleware here

app.get('/weather', async (req, res) => {
    try {
      const apiKey = 'bec63be1402eafd4472d21ee714fde06'; // Replace this with your actual API key
      const city = 'Chennai'; // Replace this with the desired city
  
      const response = await axios.get(
        `https://api.example.com/weather?q=${city}&appid=${apiKey}`
      );
  
      const weatherData = response.data;
      // Process the data as needed and send it to the client
      res.json(weatherData);
    } catch (error) {
      console.error('Error fetching weather data:', error);
      res.status(500).json({ error: 'Unable to fetch weather data' });
    }
  });

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});